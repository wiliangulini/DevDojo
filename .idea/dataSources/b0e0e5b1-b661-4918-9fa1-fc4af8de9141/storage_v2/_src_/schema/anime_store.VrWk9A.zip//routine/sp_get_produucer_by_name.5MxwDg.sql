create
    definer = root@`%` procedure sp_get_produucer_by_name(IN search varchar(100))
BEGIN
SELECT * FROM producer where name like search;
END;

